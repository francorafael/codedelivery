<?php
return [
    'fields_not_accepted' => 'As colunas :field não são aceitas nessa consulta.'
];
