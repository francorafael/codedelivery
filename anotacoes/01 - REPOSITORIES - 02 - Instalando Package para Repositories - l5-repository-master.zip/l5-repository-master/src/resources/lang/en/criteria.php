<?php
return [
    'fields_not_accepted' => 'Columns :field are not accepted in the research'
];
